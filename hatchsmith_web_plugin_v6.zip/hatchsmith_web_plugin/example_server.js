'use strict';

const express = require('express');
const { registerHatchSmith } = require('./plugins/hatchsmith/plugin');

function main() {
  const app = express();

  // Example: mount plugin into this server (single port)
  registerHatchSmith(app, {
    mountPath: '/hatchsmith',
    pythonExe: process.platform === 'win32' ? 'py -3.12' : 'python3',
    workRoot: './work/hatchsmith'
  });

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 5173;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Dev server: http://localhost:${port}/hatchsmith`);
  });
}

if (require.main === module) main();

# HatchSmith Web Plugin (for your existing webserver)

This is **NOT** a second server. It is an **Express plugin/router** you mount into your current Node webserver.
It provides:
- Mobile-first **Apple-like** UI at a mount path (default: `/hatchsmith`)
- API endpoints for conversion jobs
- A Python engine that produces the **same export outputs as `hatchSmithmain.py`** (quantize → PNG layers → hatch SVG layers → combined SVG → stats → ZIP)

## What you get (same outputs as HatchSmith)

Per input PNG, the engine writes:
- `quantized_preview.png`
- `layer_list.txt`
- `png_layers/*.png`
- `svg/*.svg` (per layer)
- `svg/combined.svg`
- `svg/svg_stats.txt`
- `export.zip` (bundle of the folder)

The web plugin additionally returns **one combined ZIP** for all uploaded PNGs.

## Requirements

- Node.js (your existing server already has it)
- Python 3.9+ available on the server machine
- Python packages: `Pillow` and `numpy` (auto-installed on first run)

## Integrate into your existing server

In your existing server file (where you already create `app = express()`):

```js
const express = require("express");
const app = express();

const { registerHatchSmith } = require("./plugins/hatchsmith/plugin");
registerHatchSmith(app, {
  mountPath: "/hatchsmith",        // where the UI lives
  pythonExe: "python",             // or "py" on Windows
  workRoot: "./work/hatchsmith"    // job temp/output folder
});

// ... your existing routes here ...

// your existing listen() here
```

That’s it.

## Dev test (optional)

This repo includes `example_server.js` only for testing:

```bash
npm install
npm run dev
```

Then open:
- http://localhost:5173/hatchsmith

## Notes

- Conversion runs in a queue (1 job at a time) to avoid RAM explosions.
- UI shows progress + log lines streamed from the Python engine.



## Troubleshooting

### Pillow ImportError: cannot import name '_imaging'
This happens when you run HatchSmith with an incompatible Python build (commonly the free-threaded *t* build like `python3.13t.exe`).

Fix:
- Install normal CPython 3.12 (recommended) or 3.13 (non-*t*)
- Configure the plugin with:

```js
registerHatchSmith(app, { pythonExe: "py -3.12" });
```

This plugin creates an isolated venv under `workRoot/_venv` so it will not break your global Python packages (e.g. OpenVINO).

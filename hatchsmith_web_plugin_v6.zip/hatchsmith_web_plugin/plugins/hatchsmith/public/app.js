'use strict';

const el = (id) => document.getElementById(id);

const fileInput = el('fileInput');
const drop = el('drop');
const btnConvert = el('btnConvert');
const btnClear = el('btnClear');
const btnFolder = el('btnFolder');
const btnHelp = el('btnHelp');
const helpPanel = el('helpPanel');

const statusText = el('statusText');
const progressBar = el('progressBar');
const results = el('results');
const logEl = el('log');

const fields = {
  n_colors: el('n_colors'),
  pen_mm: el('pen_mm'),
  draw_w_mm: el('draw_w_mm'),
  draw_h_mm: el('draw_h_mm'),
  keep_aspect: el('keep_aspect'),
  use_crosshatch: el('use_crosshatch'),
  angle_set: el('angle_set'),
  export_png_layers: el('export_png_layers'),
  export_svg_layers: el('export_svg_layers'),
  export_svg_combined: el('export_svg_combined'),
  force_user_order: el('force_user_order'),
  labelsText: el('labelsText')
};

let selectedFiles = [];
let currentJobId = null;

// File System Access API (Chromium/Edge). Optional.
let dirHandle = null;
const canPickDir = (typeof window.showDirectoryPicker === 'function');

function setStatus(text, p) {
  statusText.textContent = text;
  const pct = Math.max(0, Math.min(1, p ?? 0)) * 100;
  progressBar.style.width = pct.toFixed(1) + '%';
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  }[c]));
}

function renderFiles() {
  results.innerHTML = '';
  if (!selectedFiles.length) {
    results.innerHTML = '<div class="small">No files selected.</div>';
    return;
  }
  for (const f of selectedFiles) {
    const div = document.createElement('div');
    div.className = 'resultCard';
    div.innerHTML = `
      <div class="resultMain">
        <div class="resultTitle">${escapeHtml(f.name)}</div>
        <div class="resultMeta">${Math.round(f.size/1024)} KB</div>
      </div>
      <div class="resultActions">
        <span class="small">ready</span>
      </div>
    `;
    results.appendChild(div);
  }
}

function optionsFromUI() {
  return {
    n_colors: parseInt(fields.n_colors.value, 10),
    pen_mm: parseFloat(fields.pen_mm.value),
    draw_w_mm: parseFloat(fields.draw_w_mm.value),
    draw_h_mm: parseFloat(fields.draw_h_mm.value),
    keep_aspect: fields.keep_aspect.value === 'true',
    use_crosshatch: fields.use_crosshatch.value === 'true',
    angle_set: fields.angle_set.value,
    export_png_layers: fields.export_png_layers.value === 'true',
    export_svg_layers: fields.export_svg_layers.value === 'true',
    export_svg_combined: fields.export_svg_combined.value === 'true',
    force_user_order: fields.force_user_order.value === 'true'
  };
}

fileInput.addEventListener('change', () => {
  selectedFiles = Array.from(fileInput.files || []).filter(f => f.type === 'image/png' || f.name.toLowerCase().endsWith('.png'));
  renderFiles();
});

drop.addEventListener('dragover', (e) => {
  e.preventDefault();
  drop.classList.add('dragover');
});
drop.addEventListener('dragleave', () => drop.classList.remove('dragover'));
drop.addEventListener('drop', (e) => {
  e.preventDefault();
  drop.classList.remove('dragover');
  const files = Array.from(e.dataTransfer.files || []).filter(f => f.type === 'image/png' || f.name.toLowerCase().endsWith('.png'));
  if (files.length) {
    selectedFiles = files;
    const dt = new DataTransfer();
    files.forEach(f => dt.items.add(f));
    fileInput.files = dt.files;
    renderFiles();
  }
});

btnClear.addEventListener('click', () => {
  selectedFiles = [];
  fileInput.value = '';
  renderFiles();
  setStatus('Ready.', 0);
  logEl.textContent = '';
  currentJobId = null;
});

btnHelp.addEventListener('click', () => {
  helpPanel.hidden = !helpPanel.hidden;
});


if (canPickDir) {
  btnFolder.hidden = false;
  btnFolder.addEventListener('click', async () => {
    await chooseOutputFolder();
  });
} else {
  // Keep it hidden; classic download will be used.
  btnFolder.hidden = true;
}


function appendLog(lines) {
  if (!Array.isArray(lines)) return;
  logEl.textContent = lines.join('\n');
  logEl.scrollTop = logEl.scrollHeight;
}



async function chooseOutputFolder() {
  if (!canPickDir) return null;
  try {
    dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
    setStatus('Output folder selected.', 0.05);
    return dirHandle;
  } catch (e) {
    // user canceled
    return null;
  }
}

async function saveZipToFolder(downloadUrl, suggestedName) {
  if (!canPickDir) return false;

  // Ensure we have a folder handle
  if (!dirHandle) {
    const h = await chooseOutputFolder();
    if (!h) return false;
  }

  const resp = await fetch(downloadUrl, { cache: 'no-store' });
  if (!resp.ok) throw new Error(await resp.text());
  const blob = await resp.blob();

  // Write ZIP into selected folder
  const fileHandle = await dirHandle.getFileHandle(suggestedName, { create: true });
  const writable = await fileHandle.createWritable();
  await writable.write(blob);
  await writable.close();

  return true;
}


async function postConvert() {
  if (!selectedFiles.length) {
    setStatus('Pick at least one PNG.', 0);
    return null;
  }

  btnConvert.disabled = true;
  setStatus('Uploading…', 0.02);

  const fd = new FormData();
  for (const f of selectedFiles) fd.append('files', f, f.name);
  fd.append('options', JSON.stringify(optionsFromUI()));
  fd.append('labelsText', fields.labelsText.value || '');

  const resp = await fetch('./api/convert', { method: 'POST', body: fd });
  if (!resp.ok) throw new Error(await resp.text());
  const { jobId } = await resp.json();
  return jobId;
}

async function pollJob(jobId) {
  while (true) {
    const r = await fetch(`./api/job/${jobId}`);
    const j = await r.json();

    if (j.status === 'error') {
      setStatus('Error', 1);
      appendLog((j.logs || []).concat([j.error || 'Job failed']));
      throw new Error(j.error || 'Job failed');
    }

    setStatus(j.message || j.status, j.progress || 0);
    appendLog(j.logs || []);

    if (j.status === 'done') return j;
    await new Promise(res => setTimeout(res, 450));
  }
}

function showDownload(job) {
  results.innerHTML = '';
  const div = document.createElement('div');
  div.className = 'resultCard';

  const saveBtn = canPickDir
    ? `<button class="linkBtn" id="btnSaveFolder" type="button">Save to folder</button>`
    : '';

  div.innerHTML = `
    <div class="resultMain">
      <div class="resultTitle">Export finished</div>
      <div class="resultMeta">ZIP contains PNG layers + hatch SVG layers + combined SVG + stats.</div>
    </div>
    <div class="resultActions">
      ${saveBtn}
      <a class="linkBtn" href="${job.downloadUrl}">Download ZIP</a>
    </div>
  `;
  results.appendChild(div);

  if (canPickDir) {
    const b = document.getElementById('btnSaveFolder');
    b.addEventListener('click', async () => {
      try {
        b.disabled = true;
        setStatus('Saving ZIP to folder…', 0.98);
        const ok = await saveZipToFolder(job.downloadUrl, `hatchsmith_${job.id}.zip`);
        if (ok) {
          setStatus('Saved to output folder.', 1);
        } else {
          setStatus('No folder selected. Use Download ZIP.', 1);
        }
      } catch (e) {
        console.error(e);
        setStatus('Save failed. Use Download ZIP.', 1);
      } finally {
        b.disabled = false;
      }
    });
  }
}


btnConvert.addEventListener('click', async () => {
  try {
    const jobId = await postConvert();
    if (!jobId) return;
    currentJobId = jobId;
    const job = await pollJob(jobId);
    showDownload(job);
  } catch (e) {
    console.error(e);
    results.innerHTML = `<div class="small" style="color: var(--bad);">Failed: ${escapeHtml(e.message || String(e))}</div>`;
  } finally {
    btnConvert.disabled = false;
  }
});

// init
renderFiles();
setStatus('Ready.', 0);

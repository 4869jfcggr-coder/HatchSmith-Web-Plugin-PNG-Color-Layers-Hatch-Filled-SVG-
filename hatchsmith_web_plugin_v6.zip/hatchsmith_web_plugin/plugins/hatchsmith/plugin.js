'use strict';

const path = require('path');
const express = require('express');
const multer = require('multer');

const { JobManager } = require('./src/jobManager');

function registerHatchSmith(app, opts) {
  const options = Object.assign({
    mountPath: '/hatchsmith',
    pythonExe: (process.platform === 'win32') ? 'py -3.12' : 'python3',
    workRoot: path.join(process.cwd(), 'work', 'hatchsmith'),
    maxFilesPerJob: 30,
    maxUploadBytesPerFile: 25 * 1024 * 1024
  }, opts || {});

  const router = express.Router();

  // Static UI assets
  router.use('/', express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

  // Uploads
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: options.maxUploadBytesPerFile, files: options.maxFilesPerJob },
    fileFilter: (req, file, cb) => {
      const ok = (file.mimetype === 'image/png' || file.originalname.toLowerCase().endsWith('.png'));
      cb(ok ? null : new Error('Only PNG files are allowed.'), ok);
    }
  });

  const jm = new JobManager({
    pythonExe: options.pythonExe,
    workRoot: options.workRoot
  });

  router.get('/api/ping', (req, res) => {
    res.json({ ok: true, time: new Date().toISOString() });
  });

  router.post('/api/convert', upload.array('files', options.maxFilesPerJob), (req, res) => {
    try {
      const files = req.files || [];
      if (!files.length) return res.status(400).json({ error: 'No files uploaded.' });

      let optionsJson = {};
      if (req.body && req.body.options) {
        try { optionsJson = JSON.parse(req.body.options); } catch { optionsJson = {}; }
      }
      // Labels text (optional)
      const labelsText = (req.body && typeof req.body.labelsText === 'string') ? req.body.labelsText : '';

      const job = jm.createJob(files, optionsJson, labelsText);
      res.json({ jobId: job.id });
    } catch (err) {
      res.status(500).json({ error: String(err && err.message ? err.message : err) });
    }
  });

  router.get('/api/job/:id', (req, res) => {
    const job = jm.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found.' });

    res.json({
      id: job.id,
      status: job.status,
      progress: job.progress,
      message: job.message,
      logs: job.logs.slice(-250), // last lines for UI
      error: job.status === 'error' ? job.error : null,
      downloadUrl: (job.status === 'done') ? `${options.mountPath}/api/job/${job.id}/download` : null
    });
  });

  router.get('/api/job/:id/download', (req, res) => {
    const job = jm.getJob(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found.' });
    if (job.status !== 'done' || !job.outputZip) return res.status(400).json({ error: 'Job not finished.' });

    res.setHeader('Content-Disposition', `attachment; filename="hatchsmith_${job.id}.zip"`);
    res.setHeader('Content-Type', 'application/zip');
    // Stream ZIP file
    const fs = require('fs');
    fs.createReadStream(job.outputZip).pipe(res);
  });


  // Defensive error handler (keeps server alive on route exceptions)
  // eslint-disable-next-line no-unused-vars
  router.use((err, req, res, next) => {
    console.error('[HatchSmith] Route error:', err);
    if (res.headersSent) return;
    res.status(500).json({ error: String(err && (err.stack || err.message) || err) });
  });

  // Mount router into the existing app (same server, same port)
  app.use(options.mountPath, router);

  return { router, jobManager: jm };
}

module.exports = { registerHatchSmith };

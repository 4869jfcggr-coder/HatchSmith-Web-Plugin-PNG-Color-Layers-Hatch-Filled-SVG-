'use strict';

const os = require('os');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const { spawn } = require('child_process');
const { nanoid } = require('nanoid');
const archiver = require('archiver');

async function ensureDir(p) { await fsp.mkdir(p, { recursive: true }); }

function safeName(name) {
  const base = path.basename(name || 'image.png');
  return base.replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, ' ').trim();
}

function clamp01(x){ return Math.max(0, Math.min(1, x)); }

function isWin() { return process.platform === 'win32'; }

function parseCmd(cmdStr) {
  // very simple split, supports quoted segments
  const s = String(cmdStr || '').trim();
  if (!s) return null;
  const re = /"([^"]+)"|'([^']+)'|(\S+)/g;
  const parts = [];
  let m;
  while ((m = re.exec(s)) !== null) {
    parts.push(m[1] || m[2] || m[3]);
  }
  if (!parts.length) return null;
  return { exe: parts[0], args: parts.slice(1) };
}

async function fileExists(p) {
  try { await fsp.access(p, fs.constants.F_OK); return true; } catch { return false; }
}

function venvPythonPath(venvDir) {
  return isWin()
    ? path.join(venvDir, 'Scripts', 'python.exe')
    : path.join(venvDir, 'bin', 'python');
}

function prettyCmd(c) {
  return c.exe + (c.args && c.args.length ? ' ' + c.args.join(' ') : '');
}

async function runCapture(cmd, args, opts) {
  return await new Promise((resolve) => {
    const child = spawn(cmd, args, Object.assign({ stdio: ['ignore', 'pipe', 'pipe'] }, opts || {}));
    let out = '';
    let err = '';
    child.stdout.on('data', d => out += d.toString('utf8'));
    child.stderr.on('data', d => err += d.toString('utf8'));
    child.on('close', code => resolve({ code, out, err }));
    child.on('error', e => resolve({ code: 999, out: '', err: String(e) }));
  });
}

function looksLikeFreeThreaded(exePath, versionText) {
  const p = String(exePath || '').toLowerCase();
  const v = String(versionText || '').toLowerCase();
  // python3.13t.exe is the common marker on Windows free-threaded builds
  if (p.endsWith('python3.13t.exe') || p.endsWith('python3.12t.exe') || p.endsWith('python3.11t.exe')) return true;
  if (p.endsWith('t.exe')) return true;
  if (v.includes('free-thread') || v.includes('free threaded') || v.includes('nogil')) return true;
  return false;
}

class JobManager {
  constructor(opts) {
    this.opts = Object.assign({
      // You can pass: "py -3.12" or "py -3.13" or an absolute python path
      pythonExe: isWin() ? 'py -3.12' : 'python3',
      workRoot: path.join(process.cwd(), 'work', 'hatchsmith'),
      venvName: '_venv',
      // Pinned requirements to avoid conflicts with global installs (e.g. OpenVINO)
      requirements: [
        'pip<26',
        'setuptools',
        'wheel',
        'numpy<2.4',     // OpenVINO wants <2.4, and wheels exist
        'Pillow>=10.4'   // compiled wheel for normal CPython builds
      ],
      cleanupMinutes: 45,
      maxLogLines: 5000
    }, opts || {});

    this.jobs = new Map();
    this.queue = [];
    this.running = false;

    // Cache venv python path once created
    this._venvPy = null;

    setInterval(() => this._cleanup(), 60_000).unref();
  }

  createJob(files, optionsJson, labelsText) {
    const id = nanoid(12);
    const workDir = path.join(this.opts.workRoot, id);
    const job = {
      id,
      createdAt: Date.now(),
      status: 'queued', // queued|running|done|error
      progress: 0,
      message: 'Queued',
      logs: [],
      error: null,
      workDir,
      files: files.map(f => ({ originalName: safeName(f.originalname), buffer: f.buffer })),
      options: optionsJson || {},
      labelsText: labelsText || '',
      outputZip: null
    };
    this.jobs.set(id, job);
    this.queue.push(id);
    this._pump();
    return job;
  }

  getJob(id) { return this.jobs.get(id) || null; }

  _log(job, msg) {
    const line = `[${new Date().toISOString()}] ${msg}`;
    job.logs.push(line);
    if (job.logs.length > this.opts.maxLogLines) job.logs.splice(0, job.logs.length - this.opts.maxLogLines);
  }

  _updateOverallProgress(job, fileIndex, fileProgress, totalFiles) {
    const overall = (fileIndex + clamp01(fileProgress)) / Math.max(1, totalFiles);
    job.progress = clamp01(overall);
  }

  async _pump() {
    if (this.running) return;
    const id = this.queue.shift();
    if (!id) return;
    const job = this.jobs.get(id);
    if (!job) return;

    this.running = true;
    job.status = 'running';
    job.message = 'Starting…';
    job.progress = 0;

    try {
      await ensureDir(job.workDir);
      const inDir = path.join(job.workDir, 'in');
      const outDir = path.join(job.workDir, 'out');
      await ensureDir(inDir);
      await ensureDir(outDir);

      const labelsFile = path.join(job.workDir, 'labels.txt');
      await fsp.writeFile(labelsFile, job.labelsText || '', 'utf8');

      // Ensure isolated Python venv (so we don't break your global Python / OpenVINO stack)
      const venvPy = await this._ensureVenv(job);

      const total = job.files.length;

      for (let i = 0; i < total; i++) {
        const f = job.files[i];
        const base = path.parse(f.originalName).name;
        const inPath = path.join(inDir, f.originalName);
        await fsp.writeFile(inPath, f.buffer);

        const fileOut = path.join(outDir, base);
        await ensureDir(fileOut);

        job.message = `Converting ${i+1}/${total}: ${f.originalName}`;
        this._log(job, job.message);

        await this._runPython(job, venvPy, inPath, fileOut, labelsFile, i, total);
      }

      job.message = 'Packing ZIP…';
      job.progress = 0.97;

      const zipPath = path.join(job.workDir, 'result.zip');
      await this._zipFolder(outDir, zipPath);
      job.outputZip = zipPath;

      job.status = 'done';
      job.progress = 1;
      job.message = 'Done';
      this._log(job, 'Done');

    } catch (err) {
      job.status = 'error';
      job.error = String(err && err.stack ? err.stack : err);
      job.message = 'Error';
      this._log(job, job.error);
    } finally {
      this.running = false;
      job.files.forEach(f => { f.buffer = null; });
      setImmediate(() => this._pump());
    }
  }

  async _zipFolder(folder, zipPath) {
    await ensureDir(path.dirname(zipPath));
    await new Promise((resolve, reject) => {
      const out = fs.createWriteStream(zipPath);
      const arc = archiver('zip', { zlib: { level: 9 } });

      out.on('close', resolve);
      out.on('error', reject);

      arc.on('warning', (err) => { if (err.code !== 'ENOENT') reject(err); });
      arc.on('error', reject);

      arc.pipe(out);
      arc.directory(folder, false);
      arc.finalize();
    });
  }

  streamZip(res, job) {
    fs.createReadStream(job.outputZip).pipe(res);
  }

  async _resolveBasePython(job) {
    // Prefer explicit command string from opts
    const explicit = parseCmd(this.opts.pythonExe);
    const candidates = [];
    if (explicit) candidates.push(explicit);

    // Fallback candidates
    if (isWin()) {
      candidates.push(parseCmd('py -3.13'));
      candidates.push(parseCmd('py -3.12'));
      candidates.push(parseCmd('py -3'));
      candidates.push(parseCmd('python'));
    } else {
      candidates.push(parseCmd('python3'));
      candidates.push(parseCmd('python'));
    }

    const tried = [];

    for (const c of candidates.filter(Boolean)) {
      tried.push(prettyCmd(c));
      // probe
      const probe = await runCapture(c.exe, c.args.concat(['-c', 'import sys; print(sys.executable); print(sys.version)']));
      if (probe.code !== 0) continue;

      const lines = probe.out.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      const exePath = lines[0] || '';
      const verText = lines.slice(1).join(' ');
      if (looksLikeFreeThreaded(exePath, verText)) {
        // This is the root of your Pillow/_imaging pain. Skip it.
        this._log(job, `Skipping free-threaded Python: ${exePath}`);
        continue;
      }

      this._log(job, `Using Python: ${exePath}`);
      return { cmd: c, exePath, verText };
    }

    throw new Error(
      `No suitable Python found.\nTried: ${tried.join(', ')}\n\n` +
      `Install normal CPython 3.12/3.13 (NOT the free-threaded *t* build) and set pythonExe to "py -3.12" or an absolute python.exe path.`
    );
  }

  async _ensureVenv(job) {
    if (this._venvPy && await fileExists(this._venvPy)) return this._venvPy;

    const venvDir = path.join(this.opts.workRoot, this.opts.venvName);
    const marker = path.join(venvDir, 'hatchsmith_venv_ready.txt');
    const vpy = venvPythonPath(venvDir);

    await ensureDir(this.opts.workRoot);

    if (await fileExists(marker) && await fileExists(vpy)) {
      this._venvPy = vpy;
      this._log(job, `Python venv ready: ${vpy}`);
      return vpy;
    }

    this._log(job, 'Preparing isolated Python venv (one-time)…');

    const base = await this._resolveBasePython(job);

    // Create venv
    await ensureDir(venvDir);
    const venvCreate = await runCapture(base.cmd.exe, base.cmd.args.concat(['-m', 'venv', venvDir]));
    if (venvCreate.code !== 0) {
      throw new Error(`Failed to create venv.\n${venvCreate.err || venvCreate.out}`);
    }

    // Upgrade pip & install requirements inside venv
    const pip1 = await runCapture(vpy, ['-m', 'pip', 'install', '--upgrade', '--no-warn-script-location'].concat(this.opts.requirements.slice(0,1)));
    if (pip1.code !== 0) {
      throw new Error(`pip bootstrap failed.\n${pip1.err || pip1.out}`);
    }

    const req = this.opts.requirements.slice(1);
    const pip2 = await runCapture(vpy, ['-m', 'pip', 'install', '--upgrade', '--no-warn-script-location'].concat(req));
    if (pip2.code !== 0) {
      throw new Error(
        `Dependency install failed.\n\n` +
        `${pip2.err || pip2.out}\n\n` +
        `If you still see Pillow "_imaging" errors, you are likely using a free-threaded Python. Install normal CPython and set pythonExe to "py -3.12".`
      );
    }

    await fsp.writeFile(marker, `ready\npython=${base.exePath}\n`, 'utf8');
    this._venvPy = vpy;
    this._log(job, `Python venv installed: ${vpy}`);
    return vpy;
  }

  _runPython(job, venvPy, inputPath, outDir, labelsFile, fileIndex, totalFiles) {
    return new Promise((resolve, reject) => {
      const engine = path.join(__dirname, '..', 'engine', 'hatchsmith_engine.py');

      const o = job.options || {};
      const args = [
        engine,
        '--input', inputPath,
        '--out', outDir,
        '--n_colors', String(o.n_colors ?? o.colors ?? 16),
        '--pen_mm', String(o.pen_mm ?? 1.0),
        '--draw_w_mm', String(o.draw_w_mm ?? 1000.0),
        '--draw_h_mm', String(o.draw_h_mm ?? 0.0),
        '--keep_aspect', String(o.keep_aspect ?? true),
        '--crosshatch', String(o.use_crosshatch ?? o.crosshatch ?? true),
        '--angle_set', String(o.angle_set ?? 'Auto'),
        '--export_png_layers', String(o.export_png_layers ?? true),
        '--export_svg_layers', String(o.export_svg_layers ?? true),
        '--export_svg_combined', String(o.export_svg_combined ?? true),
        '--force_user_order', String(o.force_user_order ?? false),
        '--labels_file', labelsFile,
        '--jsonl'
      ];

      const child = spawn(venvPy, args, { stdio: ['ignore','pipe','pipe'], env: Object.assign({}, process.env, { PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' }) });

      let stdoutBuf = '';
      let stderrBuf = '';

      const onLine = (line) => {
        line = String(line || '').trim();
        if (!line) return;

        try {
          const msg = JSON.parse(line);
          if (msg.type === 'log') {
            this._log(job, msg.msg);
          } else if (msg.type === 'progress') {
            const fp = Math.max(0, Math.min(100, Number(msg.value || 0))) / 100;
            this._updateOverallProgress(job, fileIndex, fp, totalFiles);
          } else if (msg.type === 'warn') {
            this._log(job, 'WARN: ' + msg.msg);
          } else if (msg.type === 'error') {
            this._log(job, 'ENGINE ERROR: ' + msg.msg);
          }
        } catch {
          this._log(job, line);
        }
      };

      child.stdout.on('data', (d) => {
        stdoutBuf += d.toString('utf8');
        let idx;
        while ((idx = stdoutBuf.indexOf('\n')) >= 0) {
          const line = stdoutBuf.slice(0, idx);
          stdoutBuf = stdoutBuf.slice(idx + 1);
          onLine(line);
        }
      });

      child.stderr.on('data', (d) => {
        stderrBuf += d.toString('utf8');
        if (stderrBuf.length > 40_000) stderrBuf = stderrBuf.slice(-40_000);
      });

      child.on('error', (e) => reject(e));
      child.on('close', (code) => {
        if (stdoutBuf.trim()) onLine(stdoutBuf.trim());
        if (code === 0) return resolve();
        const err = new Error(`Python engine failed (code ${code}).\n${stderrBuf}`);
        reject(err);
      });
    });
  }

  _cleanup() {
    const cutoff = Date.now() - (this.opts.cleanupMinutes * 60 * 1000);
    for (const [id, job] of this.jobs.entries()) {
      if (job.createdAt < cutoff && job.status !== 'running') {
        this.jobs.delete(id);
        fs.rm(job.workDir, { recursive: true, force: true }, () => {});
      }
    }
  }
}

module.exports = { JobManager };

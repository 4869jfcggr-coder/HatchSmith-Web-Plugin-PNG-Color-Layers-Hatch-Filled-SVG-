\
# hatchsmith_engine.py
# Headless engine for HatchSmith exports.
# Runs inside an isolated venv created by the Node plugin.
# If Pillow/Numpy are missing or broken, the Node side recreates the venv.

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import zipfile
import traceback
import colorsys


# Force UTF-8 output on Windows consoles (avoid cp1252 UnicodeEncodeError)
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

def jlog(msg: str):
    print(json.dumps({"type":"log","msg":msg}, ensure_ascii=False), flush=True)

def jwarn(msg: str):
    print(json.dumps({"type":"warn","msg":msg}, ensure_ascii=False), flush=True)

def jprogress(v: int):
    v=int(max(0,min(100,v)))
    print(json.dumps({"type":"progress","value":v}), flush=True)

# Imports that require compiled wheels
try:
    from PIL import Image  # type: ignore
except Exception as e:
    msg = (
        "Pillow import failed. This usually means you are using an incompatible Python build "
        "(often the free-threaded *t* build like python3.13t.exe) or a broken Pillow install.\n\n"
        f"Error: {e}\n\n"
        "Fix:\n"
        " - Install normal CPython 3.12/3.13 (NOT the *t* build)\n"
        " - Configure the plugin with pythonExe: \"py -3.12\" (recommended)\n"
    )
    print(json.dumps({"type":"error","msg":msg}, ensure_ascii=False), flush=True)
    raise

try:
    import numpy as np  # type: ignore
except Exception as e:
    msg = (
        "NumPy import failed.\n\n"
        f"Error: {e}\n"
    )
    print(json.dumps({"type":"error","msg":msg}, ensure_ascii=False), flush=True)
    raise

def safe_mkdir(p: str) -> str:
    os.makedirs(p, exist_ok=True)
    return p

def clamp(v,a,b):
    return a if v<a else b if v>b else v

def hex_to_rgb(hx):
    hx=hx.strip().lstrip("#")
    return (int(hx[0:2],16),int(hx[2:4],16),int(hx[4:6],16))

def rgb_to_hex(r,g,b):
    return f"{r:02X}{g:02X}{b:02X}"

def parse_label_list(text: str):
    lines=[l.strip() for l in text.splitlines() if l.strip()]
    items=[]
    pat=re.compile(r"^\s*(\d{2})\s*-\s*([a-zA-Z0-9_]+)\s*\(#([0-9A-Fa-f]{6})\)\s*Anteil\s*([0-9]+(?:\.[0-9]+)?)%")
    for l in lines:
        m=pat.search(l)
        if not m:
            continue
        prefix,name,hx,share=m.group(1),m.group(2),m.group(3).upper(),float(m.group(4))
        items.append((prefix,name,hx,share))
    return items

def quantize_image_rgb(img_rgb: Image.Image, n_colors: int):
    q=img_rgb.quantize(colors=n_colors,method=Image.MEDIANCUT)
    q_arr=np.array(q)
    pal=q.getpalette()[:n_colors*3]
    palette=[(pal[i],pal[i+1],pal[i+2]) for i in range(0,len(pal),3)]
    counts=np.bincount(q_arr.flatten(),minlength=n_colors)
    return q,q_arr,palette,counts

def palette_assignment_nearest(palette, desired_hex_list):
    desired_rgbs=[hex_to_rgb(hx) for hx in desired_hex_list]
    n=len(palette)
    dist=np.zeros((n,n),dtype=float)
    for i,(r,g,b) in enumerate(palette):
        for j,(rr,gg,bb) in enumerate(desired_rgbs):
            dist[i,j]=(r-rr)**2+(g-gg)**2+(b-bb)**2
    assigned={}
    used_i=set()
    used_j=set()
    for _ in range(n):
        best_i=-1
        best_j=-1
        best_val=1e18
        for i in range(n):
            if i in used_i:
                continue
            for j in range(n):
                if j in used_j:
                    continue
                v=dist[i,j]
                if v<best_val:
                    best_val=v
                    best_i=i
                    best_j=j
        assigned[best_j]=best_i
        used_i.add(best_i)
        used_j.add(best_j)
    return assigned

def hsv_v(r,g,b):
    rf,gf,bf=r/255.0,g/255.0,b/255.0
    hh,ss,vv=colorsys.rgb_to_hsv(rf,gf,bf)
    return vv,ss,hh

def spacing_mm_from_v(v, pen_mm):
    return float(clamp((0.9+(v**1.2)*3.6)*pen_mm,0.7*pen_mm,6.0*pen_mm))

def runs_from_bool_1d(arr_bool):
    r=arr_bool.astype(np.int16)
    if r.sum()==0:
        return []
    padded=np.pad(r,(1,1),constant_values=0)
    d=np.diff(padded)
    starts=np.where(d==1)[0]
    ends=np.where(d==-1)[0]-1
    if len(starts)==0 or len(ends)==0:
        return []
    m=min(len(starts),len(ends))
    return list(zip(starts[:m],ends[:m]))

def svg_header(width_mm,height_mm):
    return '<?xml version="1.0" encoding="UTF-8"?>\n'+f'<svg xmlns="http://www.w3.org/2000/svg" width="{width_mm:.3f}mm" height="{height_mm:.3f}mm" viewBox="0 0 {width_mm:.3f} {height_mm:.3f}">\n'+'<metadata>HatchSmith © FIWAtec GmbH</metadata>\n'+'<rect x="0" y="0" width="100%" height="100%" fill="white"/>\n'

def svg_footer():
    return "</svg>\n"

def angle_modes_from_choice(choice, v, use_crosshatch):
    if choice=="Horizontal":
        return ["h"]
    if choice=="Vertical":
        return ["v"]
    if choice=="Cross":
        return ["h","v"]
    if choice=="45°":
        return ["d1"]
    if choice=="-45°":
        return ["d2"]
    if choice=="Cross + 45°":
        return ["h","v","d1","d2"]
    if choice=="Auto":
        if not use_crosshatch:
            return ["h"]
        return ["h","v"] if v<0.35 else ["h"]
    return ["h"]

def diag_coords_d1(w,h,idx):
    coords=[]
    x0=max(0,idx-(h-1))
    y0=idx-x0
    x=x0
    y=y0
    while x<w and y>=0:
        coords.append((x,y))
        x+=1
        y-=1
    return coords

def diag_coords_d2(w,h,idx):
    coords=[]
    x0=max(0,idx-(h-1))
    y0=idx-x0-(h-1)
    x=x0
    y=y0
    while x<w and y<h:
        if y>=0:
            coords.append((x,y))
        x+=1
        y+=1
    return coords

def emit_hatch_paths(mask, mm_per_px, step_px, modes):
    w=mask.shape[1]
    h=mask.shape[0]
    out=[]
    paths=0
    if "h" in modes:
        for y in range(0,h,step_px):
            runs=runs_from_bool_1d(mask[y,:])
            if not runs:
                continue
            y_mm=y*mm_per_px
            for x0,x1 in runs:
                out.append(f'<path d="M {x0*mm_per_px:.3f} {y_mm:.3f} L {(x1+1)*mm_per_px:.3f} {y_mm:.3f}"/>\n')
                paths+=1
    if "v" in modes:
        for x in range(0,w,step_px):
            runs=runs_from_bool_1d(mask[:,x])
            if not runs:
                continue
            x_mm=x*mm_per_px
            for y0,y1 in runs:
                out.append(f'<path d="M {x_mm:.3f} {y0*mm_per_px:.3f} L {x_mm:.3f} {(y1+1)*mm_per_px:.3f}"/>\n')
                paths+=1
    if "d1" in modes:
        for idx in range(0,(w+h-1),step_px):
            coords=diag_coords_d1(w,h,idx)
            if not coords:
                continue
            arr=np.array([mask[y,x] for x,y in coords],dtype=bool)
            runs=runs_from_bool_1d(arr)
            if not runs:
                continue
            for a,b in runs:
                x0,y0=coords[a]
                x1,y1=coords[b]
                out.append(f'<path d="M {x0*mm_per_px:.3f} {y0*mm_per_px:.3f} L {(x1+1)*mm_per_px:.3f} {(y1+1)*mm_per_px:.3f}"/>\n')
                paths+=1
    if "d2" in modes:
        for idx in range(0,(w+h-1),step_px):
            coords=diag_coords_d2(w,h,idx)
            if not coords:
                continue
            arr=np.array([mask[y,x] for x,y in coords],dtype=bool)
            runs=runs_from_bool_1d(arr)
            if not runs:
                continue
            for a,b in runs:
                x0,y0=coords[a]
                x1,y1=coords[b]
                out.append(f'<path d="M {x0*mm_per_px:.3f} {y0*mm_per_px:.3f} L {(x1+1)*mm_per_px:.3f} {(y1+1)*mm_per_px:.3f}"/>\n')
                paths+=1
    return out,paths

def zip_folder(folder, zip_path, exclude_names=None):
    exclude_names=exclude_names or set()
    with zipfile.ZipFile(zip_path,"w",compression=zipfile.ZIP_DEFLATED) as z:
        for root,dirs,files in os.walk(folder):
            for fn in files:
                if fn in exclude_names:
                    continue
                fp=os.path.join(root,fn)
                arc=os.path.relpath(fp,folder)
                z.write(fp,arcname=arc)

def to_bool(s: str, default: bool=False) -> bool:
    if s is None:
        return default
    if isinstance(s, bool):
        return bool(s)
    t=str(s).strip().lower()
    if t in ("1","true","yes","y","on"):
        return True
    if t in ("0","false","no","n","off"):
        return False
    return default

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n_colors", type=int, default=16)
    ap.add_argument("--pen_mm", type=float, default=1.0)
    ap.add_argument("--draw_w_mm", type=float, default=1000.0)
    ap.add_argument("--draw_h_mm", type=float, default=0.0)
    ap.add_argument("--keep_aspect", default="true")
    ap.add_argument("--crosshatch", default="true")
    ap.add_argument("--angle_set", default="Auto")
    ap.add_argument("--export_png_layers", default="true")
    ap.add_argument("--export_svg_layers", default="true")
    ap.add_argument("--export_svg_combined", default="true")
    ap.add_argument("--force_user_order", default="false")
    ap.add_argument("--labels_file", default="")
    ap.add_argument("--jsonl", action="store_true")
    args=ap.parse_args()

    t0=time.time()

    inp=args.input
    out_dir=safe_mkdir(args.out)

    if not os.path.isfile(inp):
        raise SystemExit("Missing input PNG.")

    keep_aspect=to_bool(args.keep_aspect, True)
    use_crosshatch=to_bool(args.crosshatch, True)
    export_png_layers=to_bool(args.export_png_layers, True)
    export_svg_layers=to_bool(args.export_svg_layers, True)
    export_svg_combined=to_bool(args.export_svg_combined, True)
    force_user_order=to_bool(args.force_user_order, False)

    labels_text=""
    if args.labels_file and os.path.isfile(args.labels_file):
        try:
            with open(args.labels_file, "r", encoding="utf-8") as f:
                labels_text=f.read()
        except Exception:
            labels_text=""

    jlog("Opened: "+inp)
    img_rgb=Image.open(inp).convert("RGB")
    w,h=img_rgb.size
    jlog(f"Image size: {w}×{h}px")
    jprogress(5)

    n_colors=int(max(2, min(64, args.n_colors)))
    jlog(f"Quantizing to {n_colors} colors…")
    q,q_arr,palette,counts=quantize_image_rgb(img_rgb,n_colors)
    total=int(counts.sum())
    jprogress(12)

    preview_path=os.path.join(out_dir,"quantized_preview.png")
    q.convert("RGB").save(preview_path)
    jlog("Saved preview: "+preview_path)
    jprogress(16)

    if keep_aspect or float(args.draw_h_mm) <= 0.0:
        mm_per_px=float(args.draw_w_mm)/float(w)
        draw_h_mm=h*mm_per_px
    else:
        mm_per_px=float(args.draw_w_mm)/float(w)
        draw_h_mm=float(args.draw_h_mm)

    jlog(f"Target size: {float(args.draw_w_mm):.1f}mm × {draw_h_mm:.1f}mm | Pen: {float(args.pen_mm):.2f}mm")
    jprogress(20)

    labels=""
    if args.labels_file and os.path.isfile(args.labels_file):
        try:
            with open(args.labels_file,"r",encoding="utf-8") as f:
                labels=f.read()
        except Exception:
            labels=""

    parsed=parse_label_list(labels) if labels.strip() else []
    have_user_labels=(len(parsed)==n_colors)
    order=[]

    if have_user_labels and force_user_order:
        jlog("Layer naming/order: custom list")
        desired_hex=[hx for _,_,hx,_ in parsed]
        assigned=palette_assignment_nearest(palette,desired_hex)
        for idx,(prefix,name,hx,share) in enumerate(parsed):
            pidx=assigned[idx]
            order.append((prefix,name,hx,float(share),pidx))
    else:
        jlog("Layer order: automatic (dark -> light)")
        meta=[]
        for i,(r,g,b) in enumerate(palette):
            v,_,_=hsv_v(r,g,b)
            meta.append((i,v,int(counts[i])))
        meta_sorted=sorted(meta, key=lambda t:(t[1],-t[2]))
        for k,(i,v,cnt) in enumerate(meta_sorted, start=1):
            prefix=f"{k:02d}"
            hx=rgb_to_hex(*palette[i])
            name=f"layer_{prefix}"
            share=cnt/total*100.0 if total else 0.0
            order.append((prefix,name,hx,share,i))

    mapping_path=os.path.join(out_dir,"layer_list.txt")
    with open(mapping_path,"w",encoding="utf-8") as f:
        f.write("HatchSmith export list © FIWAtec GmbH\n")
        f.write(f"Source: {os.path.basename(inp)}\n")
        f.write(f"PNG: {w}×{h}px\n")
        f.write(f"Target: {float(args.draw_w_mm):.1f}mm × {draw_h_mm:.1f}mm | Pen {float(args.pen_mm):.2f}mm\n")
        f.write(f"Colors: {n_colors}\n")
        f.write(f"Hatching: {args.angle_set} | Crosshatch: {1 if use_crosshatch else 0}\n\n")
        for prefix,name,hx,share,pidx in order:
            f.write(f"{prefix} - {name} (#{hx}) Anteil {share:.2f}%\n")

    jlog("Saved layer list: "+mapping_path)
    jprogress(26)

    if export_png_layers:
        jlog("Exporting PNG layers…")
        layers_dir=safe_mkdir(os.path.join(out_dir,"png_layers"))
        for i,(prefix,name,hx,share,pidx) in enumerate(order):
            r,g,b=palette[pidx]
            mask=(q_arr==pidx).astype(np.uint8)*255
            layer=np.zeros((h,w,4),dtype=np.uint8)
            layer[...,0]=r
            layer[...,1]=g
            layer[...,2]=b
            layer[...,3]=mask
            fn=f"{prefix}_{name}_#{hx}.png"
            Image.fromarray(layer).save(os.path.join(layers_dir,fn))
            if (i%2)==0:
                jprogress(26+int(18*(i+1)/len(order)))
        jlog("PNG layers: "+layers_dir)

    jprogress(45)

    svg_dir=safe_mkdir(os.path.join(out_dir,"svg"))
    combined=[]
    stats=[]
    if export_svg_combined:
        combined.append(svg_header(float(args.draw_w_mm),draw_h_mm))

    for i,(prefix,name,hx,share,pidx) in enumerate(order):
        r,g,b=palette[pidx]
        v,_,_=hsv_v(r,g,b)
        spacing_mm=spacing_mm_from_v(v,float(args.pen_mm))
        step_px=max(1,int(round(spacing_mm/mm_per_px)))
        modes=angle_modes_from_choice(args.angle_set,v,use_crosshatch)
        mask=(q_arr==pidx)

        group=[]
        group.append(f'<g id="{prefix}_{name}" stroke="#{hx}" stroke-width="{float(args.pen_mm):.3f}" stroke-linecap="round" stroke-linejoin="round" fill="none">\n')
        paths,pc=emit_hatch_paths(mask,mm_per_px,step_px,modes)
        if pc==0:
            paths,pc=emit_hatch_paths(mask,mm_per_px,1,["h"])
        group.extend(paths)
        group.append("</g>\n")

        if export_svg_layers:
            layer_svg=os.path.join(svg_dir,f"{prefix}_{name}_{hx}.svg")
            with open(layer_svg,"w",encoding="utf-8") as f:
                f.write(svg_header(float(args.draw_w_mm),draw_h_mm))
                f.write("".join(group))
                f.write(svg_footer())

        if export_svg_combined:
            combined.append("".join(group))

        stats.append((prefix,name,hx,pc))
        jprogress(45+int(50*(i+1)/len(order)))

    if export_svg_combined:
        combined.append(svg_footer())
        combined_path=os.path.join(svg_dir,"combined.svg")
        with open(combined_path,"w",encoding="utf-8") as f:
            f.write("".join(combined))
        jlog("Combined SVG: "+combined_path)

    stats_path=os.path.join(svg_dir,"svg_stats.txt")
    with open(stats_path,"w",encoding="utf-8") as f:
        for prefix,name,hx,pc in stats:
            f.write(f"{prefix}_{name}_{hx}.svg paths={pc}\n")
    jlog("SVG stats: "+stats_path)

    jprogress(97)

    bundle=os.path.join(out_dir,"export.zip")
    zip_folder(out_dir, bundle, exclude_names={"export.zip"})

    jprogress(100)
    jlog(f"Done in {time.time()-t0:.2f}s")
    print(json.dumps({"type":"done","out":out_dir}), flush=True)

if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        err = str(e) + "\n\n" + traceback.format_exc()
        print(json.dumps({"type":"error","msg":err}, ensure_ascii=False), flush=True)
        raise
